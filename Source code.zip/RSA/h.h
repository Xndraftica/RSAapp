/*
Created by Xndraftica
Thank you for the part of the code SergiyOsadchyy (https://gist.github.com/SergiyOsadchyy/d64fe7e1f9847a4b9efaea198302b850)
*/

#ifndef H_H
#define H_H

#include <iostream>
#include <string>
#include <locale>
#include <ctime>
#include <math.h>
#include <cstdlib>
#include <Windows.h>

using namespace std;

class h
{
    public:
        h();

    protected:

    private:
};

#endif // H_H
