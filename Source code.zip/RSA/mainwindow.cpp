/*
Created by Xndraftica
*/

#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "alp.h"

#include "h.h"
#include "rsa.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_Generation_clicked()
{
    RSA Q;
    QString Outex = QString::fromLocal8Bit(Q.GoKey().c_str());
    ui->labelOut->setText(Outex);
}

void MainWindow::on_Encrypt_clicked()
{
    RSA Q;
    QString Qe = ui->lineE->text();
    QString Qn = ui->lineN->text();
    QString Qtext = ui->lineInp->text();
    string strE = Qe.toUtf8().constData();
    string strN = Qn.toUtf8().constData();
    string Stext = Qtext.toUtf8().constData();
    int intE = atoi( strE.c_str() );
    unsigned long long int intN = atoi( strN.c_str() );
    string EnTxt = Q.Encrypt(Stext,intE,intN);
    QString Outex = QString::fromUtf8(EnTxt.c_str());
    ui->labelOut->setText(Outex);
}


void MainWindow::on_Decrypt_clicked()
{
    RSA Q;
    QString Qd = ui->lineD->text();
    QString Qn = ui->lineN->text();
    QString Qtext = ui->lineInp->text();
    string strD = Qd.toUtf8().constData();
    string strN = Qn.toUtf8().constData();
    string Stext = Qtext.toUtf8().constData();
    unsigned long long int intD = atoi( strD.c_str() );
    unsigned long long int intN = atoi( strN.c_str() );
    string DeTxt = Q.Decrypt(Stext,intD,intN);
    QString Outex = QString::fromUtf8(DeTxt.c_str());
    ui->labelOut->setText(Outex);
}

void MainWindow::on_pushButton_clicked()
{
    alp window;
    window.setModal(true);
    window.exec();
}
