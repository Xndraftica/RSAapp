#include "alp.h"
#include "ui_alp.h"

alp::alp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::alp)
{
    ui->setupUi(this);
}

alp::~alp()
{
    delete ui;
}
