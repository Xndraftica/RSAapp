#ifndef ALP_H
#define ALP_H

#include <QDialog>

namespace Ui {
class alp;
}

class alp : public QDialog
{
    Q_OBJECT

public:
    explicit alp(QWidget *parent = nullptr);
    ~alp();

private:
    Ui::alp *ui;
};

#endif // ALP_H
