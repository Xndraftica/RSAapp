/*
Created by Xndraftica
Thank you for the part of the code SergiyOsadchyy (https://gist.github.com/SergiyOsadchyy/d64fe7e1f9847a4b9efaea198302b850)
*/

#ifndef RSA_H
#define RSA_H

#include "h.h"

class RSA
{
    public:
        RSA();
        string GoKey();
        string ret = "";
        string Encrypt(string txt,int e, unsigned long long int n );
        string Decrypt(string txt, unsigned long long int d, unsigned long long int n);
    protected:

    private:
        string key;
        string out;
        string alp = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz1234567890АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя.,!?=+-()%";
        short p1;
        short p2;
        unsigned long long int n;
        unsigned long long int F;
        unsigned long long int e;
        unsigned long long int k = 1;
        unsigned long long int d;
};

#endif // RSA_H
